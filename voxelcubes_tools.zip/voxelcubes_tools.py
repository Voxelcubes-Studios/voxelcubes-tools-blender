bl_info = {
    "name": "Voxelcubes Tools",
    "author": "Voxelcubes Studios",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "Panel",
    "description": "Renames selected objects with number sequence",
    "warning": "",
    "doc_url": "",
    "category": "Objects Renaming",
}

import bpy

# Panel Draw
class VoxelcubesPanel(bpy.types.Panel):
    
    bl_label = "Mesh Tools"
    bl_idname = "OBJECT_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Voxelcubes"

    def draw(self, context):
        
        layout = self.layout
        
#        self.layout.label(text="Hello World")

        row = layout.row()
        row.label(text="Rename Objects", icon="OUTLINER_OB_MESH")
        
        row = layout.row()
#        row.label(text="Prefix:")
#        col = layout.column(align=True)
        row.prop(context.scene, "mesh_prefix", text="Prefix")
        
        row = layout.row()
        row.prop(context.scene, "mesh_suffix", text="Suffix")
        
        row = layout.row()
        row.prop(context.scene, "mesh_name", text="Name")
        
        row = layout.row()
        row.prop(context.scene, "mesh_start_index", text="Start Index")
        
        layout.separator()
        
        row = layout.row()
        row.operator("rename.button_operator", text="Rename")
 
 
 # Rename Button Handler 
class RenameButtonOperator(bpy.types.Operator):
    bl_idname = "rename.button_operator"
    bl_label = "Rename"

    def execute(self, context):
        
        mesh_pre = context.scene.mesh_prefix
        mesh_suf = context.scene.mesh_suffix
        mesh_nam = context.scene.mesh_name
        mesh_index = context.scene.mesh_start_index
        
        # get selected objects
        objects = bpy.context.selected_objects

        for (i,o) in enumerate(objects):
            o.name = mesh_pre + mesh_nam + "{:1d}".format(i+mesh_index) + mesh_suf
        
        print("Renaming meshes ...")
        print(o.name)
        print("Objects naming complete")
        
        return {'FINISHED'}
    

blender_classes = [
    VoxelcubesPanel,
    RenameButtonOperator
]

# Register
def register():
    bpy.types.Scene.mesh_prefix = bpy.props.StringProperty(name="Mesh Prefix")
    bpy.types.Scene.mesh_suffix = bpy.props.StringProperty(name="Mesh Suffix")
    bpy.types.Scene.mesh_name = bpy.props.StringProperty(name="Mesh Name")
    
    bpy.types.Scene.mesh_start_index = bpy.props.IntProperty(
        name="Mesh Start Index",
        description="Set starting index",
        default=0,
        min=0,
        max=1000000,
        step=1
    )
    
    for blender_class in blender_classes:
        bpy.utils.register_class(blender_class)

# Unregister
def unregister():
    del bpy.types.Scene.mesh_prefix
    del bpy.types.Scene.mesh_suffix
    del bpy.types.Scene.mesh_name
    del bpy.types.Scene.mesh_start_index
    
    for blender_class in blender_classes:
        bpy.utils.unregister_class(blender_class)
